-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 21, 2014 at 07:16 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `emedical`
--

-- --------------------------------------------------------

--
-- Table structure for table `doc_info`
--

CREATE TABLE IF NOT EXISTS `doc_info` (
  `dname` varchar(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `hospitalname` varchar(50) NOT NULL,
  `specilizer` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  PRIMARY KEY (`dname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doc_info`
--

INSERT INTO `doc_info` (`dname`, `department`, `username`, `password`, `emailid`, `contactno`, `gender`, `hospitalname`, `specilizer`, `category`) VALUES
('aksh', 'heart', 'aksk1234', '90909090', 'daksh@gmail.com', '8900989090', 'male', 'gtb', 'heart', 'senior'),
('daksh', 'heart', 'daksk1234', '', 'daksh@gmail.com', '8900989090', 'male', 'gtb', 'heart', 'senior'),
('manisha', 'skin', 'manisha123', 'phpphp', 'manisha@gmail.com', '9876543210', 'female', 'apollo', 'skin', 'junior');

-- --------------------------------------------------------

--
-- Table structure for table `doc_login`
--

CREATE TABLE IF NOT EXISTS `doc_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Department` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doc_login`
--

INSERT INTO `doc_login` (`username`, `password`, `Department`) VALUES
('astha123', '54321', 'heart'),
('manisha123', 'phpphp', 'skin'),
('daksk1234', '', 'heart'),
('aksk1234', '90909090', 'heart');
